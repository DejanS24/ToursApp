package model.state;

import model.data.IzvedbaTure;

public abstract class StanjeIzvedbe {

	public void otpocniIzvedbu(IzvedbaTure it){
		return;
	}
	
	public void zavrsiIzvedbu(IzvedbaTure it){
		return;
	}
	
	public void otkaziIzvedbu(IzvedbaTure it){
		return;
	}
}
