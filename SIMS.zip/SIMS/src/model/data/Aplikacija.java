package model.data;

import java.util.Date;

public class Aplikacija {
	public static boolean napraviTuru(String drzava, String grad){
		//proveriGrad()
		return true;
	}
}
