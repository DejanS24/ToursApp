package model.data;

public class Ocena {

	int vrednost;

	public Ocena ()
	{
		
	}
	public Ocena(int o)
	{
		this.vrednost=o;
	}
	public int getVrednost() {
		return vrednost;
	}

	public void setVrednost(int vrednost) {
		this.vrednost = vrednost;
	}
	
}
