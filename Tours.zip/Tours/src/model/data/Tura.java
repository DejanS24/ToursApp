package model.data;

public class Tura {

}
