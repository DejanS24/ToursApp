package model.collections;

import java.util.ArrayList;

import model.data.Lokacija;

public class Lokacije {
	ArrayList<Lokacija> lokacije;
}
