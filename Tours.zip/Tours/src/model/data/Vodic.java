package model.data;

public class Vodic extends Turista{

	public Vodic(String prezime, String ime, Pol pol) {
		super(prezime, ime, pol);
	}

	
	public void MakeTour(){
		
	}
	
	public void DeleteTour(){
		
	}
	
}
