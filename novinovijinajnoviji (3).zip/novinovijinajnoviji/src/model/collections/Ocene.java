package model.collections;

import java.util.ArrayList;

import model.data.Ocena;

public class Ocene {

	ArrayList<Ocena> ocene;

	public ArrayList<Ocena> getOcene() {
		return ocene;
	}

	public void setOcene(ArrayList<Ocena> ocene) {
		this.ocene = ocene;
	}
	
}
