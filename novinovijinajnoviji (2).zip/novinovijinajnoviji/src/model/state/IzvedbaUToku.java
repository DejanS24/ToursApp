package model.state;

public class IzvedbaUToku extends StanjeIzvedbe{

}
