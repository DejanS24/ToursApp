package model.data;

import java.util.ArrayList;
import java.util.Date;

public class IzvedbaTure extends Tura{

	Date pocetak;
	Date kraj;
	int cena;
	ArrayList<Lokacija> lokIzvedbe;
	public Date getPocetak() {
		return pocetak;
	}
	public void setPocetak(Date pocetak) {
		this.pocetak = pocetak;
	}
	public Date getKraj() {
		return kraj;
	}
	public void setKraj(Date kraj) {
		this.kraj = kraj;
	}
	public int getCena() {
		return cena;
	}
	public void setCena(int cena) {
		this.cena = cena;
	}
	public ArrayList<Lokacija> getLokIzvedbe() {
		return lokIzvedbe;
	}
	public void setLokIzvedbe(ArrayList<Lokacija> lokIzvedbe) {
		this.lokIzvedbe = lokIzvedbe;
	}
	@Override
	public String toString() {
		return idTure + "|" + pocetak + "|" + kraj + "|" + cena + "|" + LocToString();
	}
	
	public String LocToString(){
		String str = "";
		for (int i = 0; i < lokIzvedbe.size(); i++) {
			str = str + lokIzvedbe.get(i) + ";";
		}
		str = str.substring(0, str.length() - 1);
		return str;
	}
	
	
	
}
