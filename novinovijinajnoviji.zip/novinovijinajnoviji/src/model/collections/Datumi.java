package model.collections;

import java.util.ArrayList;
import java.util.Date;

public class Datumi {
	ArrayList<ArrayList<Date>> datumi;
}
