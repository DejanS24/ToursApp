package model.collections;

import java.util.ArrayList;

import model.data.Komentar;

public class Komentari {

	ArrayList<Komentar> komentari;

	public ArrayList<Komentar> getKomentari() {
		return komentari;
	}

	public void setKomentari(ArrayList<Komentar> komentari) {
		this.komentari = komentari;
	}
	
	
	
}
