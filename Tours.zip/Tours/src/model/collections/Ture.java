package model.collections;

import java.util.ArrayList;

import model.data.Tura;

public class Ture {

	ArrayList<Tura> ture;

	public ArrayList<Tura> getTure() {
		return ture;
	}

	public Ture(ArrayList<Tura> ture) {
		super();
		this.ture = ture;
	}

	public void setTure(ArrayList<Tura> ture) {
		this.ture = ture;
	}

	public Ture() {
		super();
	}
	
	
	
}
