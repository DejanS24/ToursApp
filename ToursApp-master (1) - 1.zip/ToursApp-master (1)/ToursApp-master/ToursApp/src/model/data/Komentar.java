package model.data;

public class Komentar {

	String naziv;
	String telo;
	
	public String getNaziv() {
		return naziv;
	}
	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}
	public String getTelo() {
		return telo;
	}
	public void setTelo(String telo) {
		this.telo = telo;
	}
	
}
