package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.LineBorder;
import model.collections.Ture;
import model.data.Korisnik;

@SuppressWarnings("serial")
public class TuristaWindow extends Window{

	JPanel content = new JPanel();
	
	Korisnik turista;
	Ture ture;
	
	public TuristaWindow(Korisnik korisnik, Ture t) throws IOException{
		super(600,500);
		turista = korisnik;
		ture = t;
		setTitle("ToursApp - " + turista.getKorisnickoIme());
		
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(550, ture.getTure().size()*100));
		
		
		JPanel optionsPan = new JPanel();
		
		for(int i=0 ; i<ture.getTure().size() ; i++){
		    
		    JPanel turaPanel = new JPanel();
		    turaPanel.setBackground(new Color(60, 179, 113));
		    turaPanel.setBorder(new LineBorder(new Color(64, 224, 208), 4));
		    turaPanel.setPreferredSize(new Dimension(450, 100));
			turaPanel.setLayout(new BorderLayout(0, 0));
		    
			JButton openTura = new JButton("Otvori turu");
		    openTura.setPreferredSize(new Dimension(100,20));
		    turaPanel.add(openTura, BorderLayout.EAST);
			
		    JTextField titleTure = new JTextField();
			titleTure.setText(ture.getTure().get(i).getGrad().getGrad());
			turaPanel.add(titleTure, BorderLayout.NORTH);
			titleTure.setColumns(10);
			
			BufferedImage myPicture = ImageIO.read(new File("Desert.jpg"));
			JLabel picLabel = new JLabel(new ImageIcon(myPicture));
			picLabel.setPreferredSize(new Dimension(90,90));
			turaPanel.add(picLabel,BorderLayout.WEST);
			
			JTextPane txtpnOvdeIdeOpis = new JTextPane();
			//txtpnOvdeIdeOpis.setText(ture.getTure().get(i).getVodic());
			turaPanel.add(txtpnOvdeIdeOpis, BorderLayout.CENTER);
			
			panel.add(turaPanel);
			
		}

		JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
				new JScrollPane(panel,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER),
				optionsPan);
		splitPane.setResizeWeight(0);
		content.add(splitPane,BorderLayout.CENTER);

		
		add(content);
				
	}
}
