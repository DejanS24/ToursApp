package gui;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

import model.collections.Korisnici;
import model.collections.Ture;
import model.data.IzvedbaTure;
import model.data.Korisnik;
import model.data.Tura;
import model.data.Turista;
import model.data.Vodic;
import util.FilesReader;
import util.FilesWriter;
import model.data.Tura;

public class MyApp {
	
	private static Korisnici korisnici;
	private static Ture ture;

	@SuppressWarnings({ "static-access" })
	public static void main(String[] args) throws IOException, ParseException, InterruptedException {
		FilesReader fr = new FilesReader();
		
		ture.setTure(fr.procitajTure());
		korisnici.setKorisnici(fr.procitajKorisnike());
		
		Korisnici kor = new Korisnici(korisnici.getKorisnici());
		Ture tur = new Ture(ture.getTure());
		
		FilesWriter fw = new FilesWriter();
		fw.writeUsers(kor);
		fw.writeTours(tur);
		
		LogInWindow login = new LogInWindow();
		login.setKorisnici(kor);
		login.setVisible(true);
		
		waitForButton(login);
		
		Korisnik korisnik = login.getK();
		System.out.println(korisnik);
		
		if (korisnik instanceof Vodic){
			VodicWindow vodicWin = new VodicWindow(korisnik, tur);
			vodicWin.setVisible(true);
		}else if (korisnik instanceof Turista){
			TuristaWindow turistaWin = new TuristaWindow(korisnik, tur);
			turistaWin.setVisible(true);
		}else{
			AdminWindow adminWin = new AdminWindow(korisnik);
			adminWin.setVisible(true);
		}
	}
	/*
	public static boolean jeZauzet(Date datumPocetka, Date DatumKraja, Turista t, Ture ture){
		for (int i = 0; i < ture.duzina(); i++){
			for (int j = 0; i < ture.getTure().get(j).getListaIzvedbi().getIzvedbeTure().size(); j++){
				ture.getTure().get(j).getListaIzvedbi().getIzvedbeTure().
			}
		}
		return false;
	}*/
	
	static boolean postojiTura(String grad, String drzava){
		for (Tura t : ture.getTure()){
			if (t.getGrad().getGrad() == grad){
				return true;
			}
			if (t.getGrad().getDrzava() == drzava){
				return true;
			}
		}
		return false;
	}
	
	static boolean proveriIzvedbu(Vodic v, Date pocetak, Date kraj){
		Date danas = new Date();
		if (pocetak.after(kraj) || danas.after(pocetak)){
			return false;
		}
		
		for (Tura ture : ture.getTure()){
			for (IzvedbaTure izvedba : ture.getListaIzvedbi().getIzvedbeTure()){
				for (String turista : izvedba.getTuristi()){
					if (turista == v.getBrojTelefona()){
						if ((pocetak.after(izvedba.getPocetak()) && pocetak.before(izvedba.getKraj())) || (kraj.after(izvedba.getPocetak()) && kraj.before(izvedba.getKraj()))){
							return false;
						}
					}
				}
			}
		}
		
		return true;// moze se dodat
	}
	
	static void waitForButton(LogInWindow login) throws InterruptedException{
		while (login.isVisible()){
			Thread.sleep(100);
		}
	}

}
