package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;

public class LokacijaIzvedbeWindow extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField poljeNazivLokacije;
	private JTextField poljeCena;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			LokacijaIzvedbeWindow dialog = new LokacijaIzvedbeWindow();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public LokacijaIzvedbeWindow() {
		setBounds(550, 100, 507, 394);
		setTitle("Dodavanje lokacija izvedbe ture");
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		GridBagLayout gbl_contentPanel = new GridBagLayout();
		gbl_contentPanel.columnWidths = new int[]{0, 0, 0, 0, 0, 0};
		gbl_contentPanel.rowHeights = new int[]{0, 0, 0, 0, 0, 60, 0, 0};
		gbl_contentPanel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_contentPanel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		contentPanel.setLayout(gbl_contentPanel);
		{
			JLabel lblNazviLokacije = new JLabel("Naziv lokacije: ");
			GridBagConstraints gbc_lblNazviLokacije = new GridBagConstraints();
			gbc_lblNazviLokacije.insets = new Insets(0, 0, 5, 5);
			gbc_lblNazviLokacije.gridx = 2;
			gbc_lblNazviLokacije.gridy = 1;
			contentPanel.add(lblNazviLokacije, gbc_lblNazviLokacije);
		}
		{
			poljeNazivLokacije = new JTextField();
			GridBagConstraints gbc_poljeNazivLokacije = new GridBagConstraints();
			gbc_poljeNazivLokacije.insets = new Insets(0, 0, 5, 0);
			gbc_poljeNazivLokacije.fill = GridBagConstraints.HORIZONTAL;
			gbc_poljeNazivLokacije.gridx = 4;
			gbc_poljeNazivLokacije.gridy = 1;
			contentPanel.add(poljeNazivLokacije, gbc_poljeNazivLokacije);
			poljeNazivLokacije.setColumns(10);
		}
		{
			JLabel lblCena = new JLabel("Cena: ");
			GridBagConstraints gbc_lblCena = new GridBagConstraints();
			gbc_lblCena.insets = new Insets(0, 0, 5, 5);
			gbc_lblCena.gridx = 2;
			gbc_lblCena.gridy = 3;
			contentPanel.add(lblCena, gbc_lblCena);
		}
		{
			poljeCena = new JTextField();
			GridBagConstraints gbc_poljeCena = new GridBagConstraints();
			gbc_poljeCena.insets = new Insets(0, 0, 5, 0);
			gbc_poljeCena.fill = GridBagConstraints.HORIZONTAL;
			gbc_poljeCena.gridx = 4;
			gbc_poljeCena.gridy = 3;
			contentPanel.add(poljeCena, gbc_poljeCena);
			poljeCena.setColumns(10);
		}
		{
			JLabel lblOpisLokacije = new JLabel("Opis lokacije: ");
			GridBagConstraints gbc_lblOpisLokacije = new GridBagConstraints();
			gbc_lblOpisLokacije.insets = new Insets(0, 0, 5, 5);
			gbc_lblOpisLokacije.gridx = 2;
			gbc_lblOpisLokacije.gridy = 5;
			contentPanel.add(lblOpisLokacije, gbc_lblOpisLokacije);
		}
		{
			JTextPane textPane = new JTextPane();
			GridBagConstraints gbc_textPane = new GridBagConstraints();
			gbc_textPane.insets = new Insets(0, 0, 5, 0);
			gbc_textPane.fill = GridBagConstraints.BOTH;
			gbc_textPane.gridx = 4;
			gbc_textPane.gridy = 5;
			contentPanel.add(textPane, gbc_textPane);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
				
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}

