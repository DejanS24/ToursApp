package model.collections;

public abstract class Kolekcija {

}
