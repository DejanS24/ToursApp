package model.data;

public class Vodic extends Osoba{

	public Vodic(String prezime, String ime, Pol pol) {
		super(prezime, ime, pol);
	}

}
