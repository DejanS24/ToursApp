package model.collections;

import java.util.ArrayList;

import model.data.IzvedbaTure;

public class IzvedbeTure {

	ArrayList<IzvedbaTure> izvedbeTure;
	
}
