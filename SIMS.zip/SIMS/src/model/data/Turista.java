package model.data;
import java.util.Date;
import model.collections.IzvedbeTure;

import model.collections.Ture;
public class Turista extends Osoba{
	
	//Ture t = new Ture();

	public Turista(String korisnickoIme, String lozinka, String prezime, String ime, Pol pol, String brojTelefona) {
		super(korisnickoIme, lozinka,prezime, ime, pol, brojTelefona);
	}
	
}
