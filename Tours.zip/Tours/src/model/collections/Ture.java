package model.collections;

public class Ture {

}
