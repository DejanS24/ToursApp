package model.data;

public class Vodic extends Turista{

	public Vodic(String korisnickoIme, String lozinka, String prezime, String ime, Pol pol) {
		super(korisnickoIme, lozinka, prezime, ime, pol);
	}

	
	
}
