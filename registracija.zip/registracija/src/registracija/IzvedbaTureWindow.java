package registracija;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class IzvedbaTureWindow extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField poljePocetak;
	private JTextField poljeKraj;
	private JTextField poljeMinTurista;
	private JTextField poljeMaxTurista;
	private JTextField poljeBrLokacija;

	/**
	 * Launch the application.
	 */
	public static int proveriBr(String br) {
		try {
			int broj = Integer.parseInt(br);
			if (broj < 1) {
				return 0;
			}
			return broj;
		} catch (Exception e) {
			return 0;
		}
	}

	public static int proveraMinMax(String minBr, String maxBr) {
		try {
			int minBrInt = Integer.parseInt(minBr);
			int maxBrInt = Integer.parseInt(maxBr);
			if (minBrInt > maxBrInt) {
				return 0;
			} else {
				return 1;
			}
		} catch (Exception e) {
			return 0;
		}

	}

	public static Date proveriDatum(String datum) {

		SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm");
		Date unetDatum = null;
		try {
			unetDatum = formatter.parse(datum);
		} catch (Exception e) {
			return null;
		}
		return unetDatum;
	}

	public static void main(String[] args) {
		try {
			IzvedbaTureWindow dialog = new IzvedbaTureWindow();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public IzvedbaTureWindow() {
		setBounds(550, 100, 475, 349);
		setTitle("Dodavanje izvedbe ture");
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		GridBagLayout gbl_contentPanel = new GridBagLayout();
		gbl_contentPanel.columnWidths = new int[] { 0, 0, 0, 0, 0 };
		gbl_contentPanel.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0 };
		gbl_contentPanel.columnWeights = new double[] { 0.0, 0.0, 0.0, 1.0,
				Double.MIN_VALUE };
		gbl_contentPanel.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0,
				0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE };
		contentPanel.setLayout(gbl_contentPanel);
		{
			JLabel label = new JLabel("Datum pocetka: ");
			GridBagConstraints gbc_label = new GridBagConstraints();
			gbc_label.insets = new Insets(0, 0, 5, 5);
			gbc_label.gridx = 1;
			gbc_label.gridy = 1;
			contentPanel.add(label, gbc_label);
		}
		{
			poljePocetak = new JTextField();
			GridBagConstraints gbc_poljePocetak = new GridBagConstraints();
			gbc_poljePocetak.insets = new Insets(0, 0, 5, 0);
			gbc_poljePocetak.fill = GridBagConstraints.HORIZONTAL;
			gbc_poljePocetak.gridx = 3;
			gbc_poljePocetak.gridy = 1;
			contentPanel.add(poljePocetak, gbc_poljePocetak);
			poljePocetak.setColumns(10);
		}
		{
			JLabel lblDatumZavrsetka = new JLabel("Datum zavrsetka:");
			GridBagConstraints gbc_lblDatumZavrsetka = new GridBagConstraints();
			gbc_lblDatumZavrsetka.insets = new Insets(0, 0, 5, 5);
			gbc_lblDatumZavrsetka.gridx = 1;
			gbc_lblDatumZavrsetka.gridy = 3;
			contentPanel.add(lblDatumZavrsetka, gbc_lblDatumZavrsetka);
		}
		{
			poljeKraj = new JTextField();
			GridBagConstraints gbc_poljeKraj = new GridBagConstraints();
			gbc_poljeKraj.insets = new Insets(0, 0, 5, 0);
			gbc_poljeKraj.fill = GridBagConstraints.HORIZONTAL;
			gbc_poljeKraj.gridx = 3;
			gbc_poljeKraj.gridy = 3;
			contentPanel.add(poljeKraj, gbc_poljeKraj);
			poljeKraj.setColumns(10);
		}
		{
			JLabel lblMinimalanBrojTurista = new JLabel(
					"Minimalan broj turista:");
			GridBagConstraints gbc_lblMinimalanBrojTurista = new GridBagConstraints();
			gbc_lblMinimalanBrojTurista.insets = new Insets(0, 0, 5, 5);
			gbc_lblMinimalanBrojTurista.gridx = 1;
			gbc_lblMinimalanBrojTurista.gridy = 5;
			contentPanel.add(lblMinimalanBrojTurista,
					gbc_lblMinimalanBrojTurista);
		}
		{
			poljeMinTurista = new JTextField();
			GridBagConstraints gbc_poljeMinTurista = new GridBagConstraints();
			gbc_poljeMinTurista.insets = new Insets(0, 0, 5, 0);
			gbc_poljeMinTurista.fill = GridBagConstraints.HORIZONTAL;
			gbc_poljeMinTurista.gridx = 3;
			gbc_poljeMinTurista.gridy = 5;
			contentPanel.add(poljeMinTurista, gbc_poljeMinTurista);
			poljeMinTurista.setColumns(10);
		}
		{
			JLabel lblMaksimalanBrojTurista = new JLabel(
					"Maksimalan broj turista: ");
			GridBagConstraints gbc_lblMaksimalanBrojTurista = new GridBagConstraints();
			gbc_lblMaksimalanBrojTurista.insets = new Insets(0, 0, 5, 5);
			gbc_lblMaksimalanBrojTurista.gridx = 1;
			gbc_lblMaksimalanBrojTurista.gridy = 7;
			contentPanel.add(lblMaksimalanBrojTurista,
					gbc_lblMaksimalanBrojTurista);
		}
		{
			poljeMaxTurista = new JTextField();
			GridBagConstraints gbc_poljeMaxTurista = new GridBagConstraints();
			gbc_poljeMaxTurista.insets = new Insets(0, 0, 5, 0);
			gbc_poljeMaxTurista.fill = GridBagConstraints.HORIZONTAL;
			gbc_poljeMaxTurista.gridx = 3;
			gbc_poljeMaxTurista.gridy = 7;
			contentPanel.add(poljeMaxTurista, gbc_poljeMaxTurista);
			poljeMaxTurista.setColumns(10);
		}
		{
			JLabel label = new JLabel("");
			GridBagConstraints gbc_label = new GridBagConstraints();
			gbc_label.insets = new Insets(0, 0, 5, 5);
			gbc_label.gridx = 1;
			gbc_label.gridy = 9;
			contentPanel.add(label, gbc_label);
		}
		{
			JLabel lblBrojLokacijaTure = new JLabel("Broj lokacija ture: ");
			GridBagConstraints gbc_lblBrojLokacijaTure = new GridBagConstraints();
			gbc_lblBrojLokacijaTure.insets = new Insets(0, 0, 0, 5);
			gbc_lblBrojLokacijaTure.gridx = 1;
			gbc_lblBrojLokacijaTure.gridy = 10;
			contentPanel.add(lblBrojLokacijaTure, gbc_lblBrojLokacijaTure);
		}
		{
			poljeBrLokacija = new JTextField();
			GridBagConstraints gbc_poljeBrLokacija = new GridBagConstraints();
			gbc_poljeBrLokacija.fill = GridBagConstraints.HORIZONTAL;
			gbc_poljeBrLokacija.gridx = 3;
			gbc_poljeBrLokacija.gridy = 10;
			contentPanel.add(poljeBrLokacija, gbc_poljeBrLokacija);
			poljeBrLokacija.setColumns(10);
		}

		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {

						String datumPocetka = poljePocetak.getText();
						String datumKraj = poljeKraj.getText();
						String minStr = poljeMinTurista.getText();
						String maxStr = poljeMaxTurista.getText();
						String brStr = poljeBrLokacija.getText();
						try {
							Date dPocetak = proveriDatum(datumPocetka);
							
							if (dPocetak==null) {
								
								JOptionPane
										.showMessageDialog(
												null,
												"Datum pocetka ture nije unet u ispravnom formatu. Format je: dd.MM.yyyy HH:mm",
												"Greska u unosu",
												JOptionPane.ERROR_MESSAGE);
								poljePocetak.setText("");
							} else {

								Date dKraj = proveriDatum(datumKraj);
								if (dKraj==null) {
									JOptionPane
											.showMessageDialog(
													null,
													"Datum kraja ture nije unet u ispravnom formatu. Format je: dd.MM.yyyy HH:mm",
													"Greska u unosu",
													JOptionPane.ERROR_MESSAGE);
									poljeKraj.setText("");
								} else {
									int minProvera = proveriBr(minStr);

									if (minProvera == 0) {
										JOptionPane
												.showMessageDialog(
														null,
														"Minimalni broj turista nije dobro unesen",
														"Greska u unosu",
														JOptionPane.ERROR_MESSAGE);
										poljeMinTurista.setText("");
									} else {

										int maxProvera = proveriBr(maxStr);

										if (maxProvera == 0) {
											JOptionPane
													.showMessageDialog(
															null,
															"Maksimalan broj turista nije dobro unesen",
															"Greska u unosu",
															JOptionPane.ERROR_MESSAGE);
											poljeMaxTurista.setText("");
										} else {

											int minMaxProvera = proveraMinMax(
													minStr, maxStr);

											if (minMaxProvera == 0)

											{
												JOptionPane
														.showMessageDialog(
																null,
																"Minimalni broj turista je veci od maksimalnog",
																"Greska u unosu",
																JOptionPane.ERROR_MESSAGE);
												poljeMinTurista.setText("");
												poljeMaxTurista.setText("");
											} else {

												int brLokacija = proveriBr(brStr);
												if (brLokacija == 0) {
													JOptionPane
															.showMessageDialog(
																	null,
																	"Broj lokacija mora biti broj",
																	"Greska u unosu",
																	JOptionPane.ERROR_MESSAGE);
													poljeBrLokacija.setText("");
												} else

												{
													for (int i = 0; i < brLokacija; i++) {
														LokacijaIzvedbeWindow lokacija = new LokacijaIzvedbeWindow();
														lokacija.setVisible(true);
													}
												}

											}
										}
									}
								}
							}
						} catch (Exception e) {
							JOptionPane
									.showMessageDialog(null,
											"Broj lokacija mora biti broj",
											"Greska u unosu",
											JOptionPane.ERROR_MESSAGE);
							poljeBrLokacija.setText("");
						}

					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
