package gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import model.collections.Ture;
import model.data.Osoba.Pol;
import model.data.Turista;

import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.RowSpec;

@SuppressWarnings("serial")
public class RegistracijaWindow extends JDialog {
	private JTextField poljeKIme;
	private JTextField poljeLozinka;
	private JLabel lblIme;
	private JTextField poljeIme;
	private JLabel lblPrezime;
	private JTextField poljePrezime;
	private JLabel lblPol;
	private JTextField poljeTelefon;
	private JLabel lblKontaktTelefon;
	private JRadioButton rdbtnMuski;
	private JRadioButton rdbtnZenski;
	private JButton btnPotvrda;
	private JButton btnOdustanak;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			RegistracijaWindow dialog = new RegistracijaWindow();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static boolean proveriPolje(String unos) {
		if (unos.compareTo("") == 0) {
			return false;
		}
		return true;
	}

	/**
	 * Create the dialog.
	 */
	public RegistracijaWindow() {
		setBackground(Color.BLACK);
		setBounds(660, 100, 591, 514);
		getContentPane().setLayout(
				new FormLayout(new ColumnSpec[] {
						FormFactory.RELATED_GAP_COLSPEC,
						ColumnSpec.decode("max(35dlu;default)"),
						FormFactory.RELATED_GAP_COLSPEC,
						FormFactory.DEFAULT_COLSPEC,
						FormFactory.RELATED_GAP_COLSPEC,
						FormFactory.DEFAULT_COLSPEC,
						FormFactory.RELATED_GAP_COLSPEC,
						ColumnSpec.decode("max(61dlu;default)"),
						FormFactory.RELATED_GAP_COLSPEC,
						ColumnSpec.decode("default:grow"),
						FormFactory.RELATED_GAP_COLSPEC,
						ColumnSpec.decode("default:grow"),
						FormFactory.RELATED_GAP_COLSPEC,
						ColumnSpec.decode("default:grow"), }, new RowSpec[] {
						FormFactory.RELATED_GAP_ROWSPEC,
						RowSpec.decode("max(31dlu;default)"),
						FormFactory.RELATED_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						RowSpec.decode("max(12dlu;default)"),
						FormFactory.RELATED_GAP_ROWSPEC,
						RowSpec.decode("max(9dlu;default)"),
						FormFactory.RELATED_GAP_ROWSPEC,
						RowSpec.decode("max(11dlu;default)"),
						FormFactory.RELATED_GAP_ROWSPEC,
						RowSpec.decode("max(11dlu;default)"), }));
		{
			JLabel lblKorisnickoIme = new JLabel("Korisnicko ime: ");
			getContentPane().add(lblKorisnickoIme, "4, 4");
		}
		{
			poljeKIme = new JTextField();
			getContentPane().add(poljeKIme, "8, 4, 3, 1, fill, default");
			poljeKIme.setColumns(10);
		}
		{
			JLabel lblLozinka = new JLabel("Lozinka: ");
			getContentPane().add(lblLozinka, "4, 8");
		}
		{
			poljeLozinka = new JPasswordField();
			getContentPane().add(poljeLozinka, "8, 8, 3, 1, fill, default");
			poljeLozinka.setColumns(10);
		}
		{
			lblIme = new JLabel(" Ime: ");
			getContentPane().add(lblIme, "4, 12");
		}
		{
			poljeIme = new JTextField();
			getContentPane().add(poljeIme, "8, 12, 3, 1, fill, default");
			poljeIme.setColumns(10);
		}
		{
			lblPrezime = new JLabel("Prezime: ");
			getContentPane().add(lblPrezime, "4, 16, 2, 1");
		}
		{
			poljePrezime = new JTextField();
			getContentPane().add(poljePrezime, "8, 16, 3, 1, fill, default");
			poljePrezime.setColumns(10);
		}
		{
			lblPol = new JLabel("Pol: ");
			getContentPane().add(lblPol, "4, 20");
		}
		{
			{
				rdbtnMuski = new JRadioButton("Muski");
				getContentPane().add(rdbtnMuski, "8, 20, center, default");
			}
			{
				rdbtnZenski = new JRadioButton("Zenski");
				getContentPane().add(rdbtnZenski, "10, 20, center, default");
			}
			{
				ButtonGroup dugmici = new ButtonGroup();
				dugmici.add(rdbtnMuski);
				dugmici.add(rdbtnZenski);
			}

			{
				lblKontaktTelefon = new JLabel("Kontakt telefon: ");
				getContentPane().add(lblKontaktTelefon, "4, 24");
			}
			{
				poljeTelefon = new JTextField();
				getContentPane()
						.add(poljeTelefon, "8, 24, 3, 1, fill, default");
				poljeTelefon.setColumns(10);
			}
		}
		btnOdustanak = new JButton("Otkazi");
		btnOdustanak.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		{
			btnPotvrda = new JButton("Potvrdi");
			btnPotvrda.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					String kIme = poljeKIme.getText();
					String lozinka = poljeLozinka.getText();
					String ime = poljeIme.getText();
					String prezime = poljePrezime.getText();
					Pol pol=Pol.Muski;
					String kontakt = poljeTelefon.getText();
					if (!proveriPolje(kIme)) {

						JOptionPane.showMessageDialog(null,
								"Unesite korisnicko ime. ","Greska pri unosu. ",JOptionPane.INFORMATION_MESSAGE);

					} else {

						if (!proveriPolje(lozinka)) {
							JOptionPane.showMessageDialog(null,
									"Unesite lozinku. ","Greska pri unosu. ",JOptionPane.INFORMATION_MESSAGE);
						} else {
							if (!proveriPolje(ime)) {

								JOptionPane.showMessageDialog(null,
										"Unesite ime. ","Greska pri unosu. ",JOptionPane.INFORMATION_MESSAGE);
							} else {
								if (!proveriPolje(prezime)) {
									JOptionPane.showMessageDialog(null,
											"Unesite prezime. ","Greska pri unosu. ",JOptionPane.INFORMATION_MESSAGE);
								} else {
									if (rdbtnMuski.isSelected()) {
										pol = Pol.Muski;
									} else if (rdbtnZenski.isSelected()) {
										pol = Pol.Zenski;
									}
									else 
									{
										JOptionPane.showMessageDialog(null, "Izaberite pol. ");
										
									}
									if (!proveriPolje(kontakt)) {
										
										JOptionPane.showMessageDialog(null,
												"Unesite kontakt telefon. ","Greska pri unosu. ",JOptionPane.INFORMATION_MESSAGE); // proveriti
																				// sa
																				// otalima
																				// da
																				// li
																				// treba
																				// da
																				// bude
																				// obavezno
																				// polje
									}
								}
							}
						}
						
						// TODO dodati proveru postojanja korsnickog imena da ne
						// unosi opet ako ga nema

					}
					if (MyApp.proveriKorisnickoIme(kIme))
					{
						JOptionPane.showMessageDialog(null, "Korisnicko ime je vec upotrebljeno unesite novo.", "Neodgovarajuci podatak",JOptionPane.WARNING_MESSAGE);
						poljeKIme.setText("");
					}
					else
					{
						Turista t=new Turista(kIme,lozinka,ime,prezime,pol,kontakt);
						
						MyApp.dodajKorisnika(t);
						Ture ture = new Ture();
						ture.setTure(MyApp.t);
						try {
							TuristaWindow w = new TuristaWindow(t,ture);
							w.setVisible(true);
						} catch (IOException e1) {
						}
						dispose();
					}
				}
			});
			getContentPane().add(btnPotvrda, "8, 32");
		}
		getContentPane().add(btnOdustanak, "10, 32");
	}

}
