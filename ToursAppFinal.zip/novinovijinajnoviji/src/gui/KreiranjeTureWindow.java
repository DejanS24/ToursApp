package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;

import model.collections.Ture;
import model.data.Korisnik;
import model.data.Lokacija;
import model.data.Tura;

@SuppressWarnings("serial")
public class KreiranjeTureWindow extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField poljeGrad;
	private JTextField poljeDrzava;

	/**
	 * Launch the application.
	 
	public static void main(String[] args) {
		try {
			KreiranjeTureWindow dialog = new KreiranjeTureWindow();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public KreiranjeTureWindow(Korisnik korisnik) {
		setBounds(100, 100, 657, 456);
		setTitle("Dodavanje ture");
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		GridBagLayout gbl_contentPanel = new GridBagLayout();
		gbl_contentPanel.columnWidths = new int[]{0, 0, 0, 273, 0, 0};
		gbl_contentPanel.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 146, 0};
		gbl_contentPanel.columnWeights = new double[]{0.0, 0.0, 0.0, 1.0, 1.0, Double.MIN_VALUE};
		gbl_contentPanel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPanel.setLayout(gbl_contentPanel);
		{
			JLabel lblGrad = new JLabel("Grad: ");
			GridBagConstraints gbc_lblGrad = new GridBagConstraints();
			gbc_lblGrad.anchor = GridBagConstraints.WEST;
			gbc_lblGrad.insets = new Insets(0, 0, 5, 5);
			gbc_lblGrad.gridx = 1;
			gbc_lblGrad.gridy = 1;
			contentPanel.add(lblGrad, gbc_lblGrad);
		}
		{
			poljeGrad = new JTextField();
			GridBagConstraints gbc_poljeGrad = new GridBagConstraints();
			gbc_poljeGrad.anchor = GridBagConstraints.NORTH;
			gbc_poljeGrad.fill = GridBagConstraints.HORIZONTAL;
			gbc_poljeGrad.insets = new Insets(0, 0, 5, 5);
			gbc_poljeGrad.gridx = 3;
			gbc_poljeGrad.gridy = 1;
			contentPanel.add(poljeGrad, gbc_poljeGrad);
			poljeGrad.setColumns(10);
		}
		{
			JLabel lblDrzava = new JLabel("Drzava: ");
			GridBagConstraints gbc_lblDrzava = new GridBagConstraints();
			gbc_lblDrzava.anchor = GridBagConstraints.WEST;
			gbc_lblDrzava.insets = new Insets(0, 0, 5, 5);
			gbc_lblDrzava.gridx = 1;
			gbc_lblDrzava.gridy = 3;
			contentPanel.add(lblDrzava, gbc_lblDrzava);
		}
		{
			poljeDrzava = new JTextField();
			GridBagConstraints gbc_poljeDrzava = new GridBagConstraints();
			gbc_poljeDrzava.fill = GridBagConstraints.HORIZONTAL;
			gbc_poljeDrzava.insets = new Insets(0, 0, 5, 5);
			gbc_poljeDrzava.gridx = 3;
			gbc_poljeDrzava.gridy = 3;
			contentPanel.add(poljeDrzava, gbc_poljeDrzava);
			poljeDrzava.setColumns(10);
		}
		{
			JLabel lblOpis = new JLabel("Opis: ");
			GridBagConstraints gbc_lblOpis = new GridBagConstraints();
			gbc_lblOpis.anchor = GridBagConstraints.WEST;
			gbc_lblOpis.insets = new Insets(0, 0, 0, 5);
			gbc_lblOpis.gridx = 1;
			gbc_lblOpis.gridy = 7;
			contentPanel.add(lblOpis, gbc_lblOpis);
		}
		
			JTextPane poljeOpisTure = new JTextPane();
			GridBagConstraints gbc_poljeOpisTure = new GridBagConstraints();
			gbc_poljeOpisTure.insets = new Insets(0, 0, 0, 5);
			gbc_poljeOpisTure.fill = GridBagConstraints.BOTH;
			gbc_poljeOpisTure.gridx = 3;
			gbc_poljeOpisTure.gridy = 7;
			contentPanel.add(poljeOpisTure, gbc_poljeOpisTure);
		
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						String grad=poljeGrad.getText();
						String drzava=poljeDrzava.getText();
						String id=MyApp.kreirajIdTure();
						String opis=poljeOpisTure.getText();
						if (MyApp.postojiTura(grad, drzava))
						{
							JOptionPane.showMessageDialog(null, "Vec postoji tura u tom gradu i drzavi! Izaberite drugi grad.","Greska",JOptionPane.WARNING_MESSAGE);
							poljeGrad.setText("");
						}
						else {
							Lokacija lokacijaTureNova=new Lokacija(drzava,grad,opis);
							Tura novaTura=new Tura(id,lokacijaTureNova,null,"novisad.jpg");
							MyApp.dodajTuru(novaTura);
							dispose();
							Ture ture2 = MyApp.vratiTure();
							VodicWindow vv;
							try {
								vv = new VodicWindow(korisnik, ture2);
								vv.setVisible(true);
							} catch (IOException e) {
								// TODO Auto-generated catch block
								//e.printStackTrace();
							}
							
							
						}
						
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}

