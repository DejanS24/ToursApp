package model.data;

public class Vodic extends Turista{

	public Vodic(String korisnickoIme, String lozinka, String prezime, String ime, Pol pol, String brojTelefona) {
		super(korisnickoIme, lozinka, prezime, ime, pol, brojTelefona);
	}
	
}
