package model.data;

public class Turista extends Osoba{

	public Turista(String prezime, String ime, Pol pol) {
		super(prezime, ime, pol);
	}
	
	

}
