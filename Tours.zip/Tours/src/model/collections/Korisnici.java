package model.collections;

import java.util.ArrayList;

import model.data.Korisnik;

public class Korisnici {

	ArrayList<Korisnik> korisnici;

	public ArrayList<Korisnik> getKorisnici() {
		return korisnici;
	}

	public void setKorisnici(ArrayList<Korisnik> korisnici) {
		this.korisnici = korisnici;
	}	
	
}
