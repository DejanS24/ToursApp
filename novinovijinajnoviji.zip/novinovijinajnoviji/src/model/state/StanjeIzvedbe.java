package model.state;

public class StanjeIzvedbe {

}
