package model.state;

public class IzvedbaOtkazana extends StanjeIzvedbe{

}
