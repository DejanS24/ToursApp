package model.state;

public class IzvedbaZavrsena {

}
