package gui;

public class MyApp {

	public static void main(String[] args) {
		LogInWindow login = new LogInWindow();
		login.setVisible(true);
		
		
	}

}
