package gui;

import model.collections.Ture;
import model.data.Korisnik;

@SuppressWarnings("serial")
public class VodicWindow extends Window{

	Korisnik vodic;
	Ture ture;
	
	public VodicWindow(Korisnik korisnik, Ture t){
		super(600,500);
		vodic = korisnik;
		ture = t;
		setTitle("ToursApp - " + vodic.getKorisnickoIme());
	}
}
