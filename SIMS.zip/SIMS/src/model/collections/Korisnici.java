package model.collections;

import java.util.ArrayList;

import model.data.Korisnik;

public class Korisnici extends Kolekcija{

	ArrayList<Korisnik> korisnici;

	public ArrayList<Korisnik> getKorisnici() {
		return korisnici;
	}

	public void setKorisnici(ArrayList<Korisnik> korisnici) {
		this.korisnici = korisnici;
	}

	public Korisnici(ArrayList<Korisnik> korisnici) {
		super();
		this.korisnici = korisnici;
	}

	public Korisnici() {
		super();
	}	
	
	public boolean proveriKorisnickoIme(String korisnickoIme){
		for (Korisnik k : korisnici){
			if (k.getKorisnickoIme() == korisnickoIme){
				return true;
			}
		}
		return false;
	}
	
	public void dodajKorisnika(Korisnik k){
		korisnici.add(k);
	}
	
	public boolean obrisiKorisnika(Korisnik k){
		if (!korisnici.contains(k)){
			return false;
		}
		for (Korisnik i : korisnici){
			if (i.getKorisnickoIme() == k.getKorisnickoIme()){
				i.setAktivan(false);			}
		}
		return true;
	}
	
	public int duzina(){
		return korisnici.size();
	}
}
