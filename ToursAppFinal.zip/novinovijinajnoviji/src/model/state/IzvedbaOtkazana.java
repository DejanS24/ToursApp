package model.state;

public class IzvedbaOtkazana extends StanjeIzvedbe{

	private static IzvedbaOtkazana instance = new IzvedbaOtkazana();
	
	public static IzvedbaOtkazana instance(){
		return instance;
	}
	
}
