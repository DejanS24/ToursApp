package model.state;

public class IzvedbaSpremna extends StanjeIzvedbe{

}
